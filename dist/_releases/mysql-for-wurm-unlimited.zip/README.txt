See mysql.properties for documentation

                        -- Friya
